#!/bin/bash
# Optional: Log deployment info
echo "Streamlit app deployed at $(date)" >> /var/log/streamlit-deploy.log
echo "Environment: $UNBARRED_PASSCODES" >> /var/log/streamlit-deploy.log